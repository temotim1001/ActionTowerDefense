// Copyright Epic Games, Inc. All Rights Reserved.

#include "ActionTowerDefense.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ActionTowerDefense, "ActionTowerDefense" );
